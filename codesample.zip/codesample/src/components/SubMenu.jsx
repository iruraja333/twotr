import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faUsers, faTachometerAlt, faBook, faBlog, faUser, faAngleLeft } from '@fortawesome/free-solid-svg-icons'
import * as constant from '../constant/constant';
import { history } from '../store';

function mapStateToProps(state) {
    return {
        activeMenu: state.ACTIONS.activeMenu
    };
}

function mapDispatchToProps(dispatch) {
    return {
        setActiveMenu: (val) => {
            dispatch({ type: constant.activeMenu, payload: val })
        }
    };
}

class SubMenu extends Component {

    subMenuAction = (val) => {
        if (val === "Dashboard")
            history.push("/twotr/dashboard");
        else if (val === "Tutors")
            history.push("/twotr/tutors");
        else if (val === "Students")
            history.push("/twotr/students");
        else if (val === "admins")
            history.push("/twotr/admin");
        else if (val === "Admin Subjects")
            history.push("/twotr/adminSubjects");
        else if (val === "User Subjects")
            history.push("/twotr/userSubjects");
        else if (val === "Blog Posts")
            history.push("/twotr/blogs");
        else if (val === "Subscriptions")
            history.push("/twotr/subscriptions");



        this.props.setActiveMenu(val);
    }
    render() {
        return (
            <ul className="subMenu">
                <li className={this.props.activeMenu === "Dashboard" ? "active" : ""} onClick={(e) => this.subMenuAction('Dashboard')}><span className="submenu-logos"><FontAwesomeIcon icon={faTachometerAlt} /></span>Dashboard</li>
                <li className={this.props.activeMenu === "Users" ? "active nonSubMenu" : ""} onClick={(e) => this.subMenuAction('Users')}><span className="submenu-logos"><FontAwesomeIcon icon={faUsers} /></span>Users <span className="arrow"><FontAwesomeIcon icon={faAngleLeft} /></span>
                    <ul className="foldableMenu">
                        <li className={this.props.activeMenu === "Tutors" ? "active" : ""} onClick={(e) => this.subMenuAction('Tutors')}><span className="submenu-logos"><FontAwesomeIcon icon={faUser} /></span>Tutors</li>
                        <li className={this.props.activeMenu === "Students" ? "active" : ""} onClick={(e) => this.subMenuAction('Students')}><span className="submenu-logos"><FontAwesomeIcon icon={faUser} /></span>Students</li>
                        <li className={this.props.activeMenu === "admins" ? "active" : ""} onClick={(e) => this.subMenuAction('admins')}><span className="submenu-logos"><FontAwesomeIcon icon={faUser} /></span>admins</li>
                    </ul>
                </li>
                <li className={this.props.activeMenu === "Subjects" ? "active nonSubMenu" : ""} onClick={(e) => this.subMenuAction('Subjects')}><span className="submenu-logos"><FontAwesomeIcon icon={faBook} /></span>Subjects<span className="arrow"><FontAwesomeIcon icon={faAngleLeft} /></span>
                    <ul className="foldableMenu m2">
                        <li className={this.props.activeMenu === "Admin Subjects" ? "active" : ""} onClick={(e) => this.subMenuAction('Admin Subjects')}><span className="submenu-logos"><FontAwesomeIcon icon={faUser} /></span>Admin Subjects</li>
                        <li className={this.props.activeMenu === "User Subjects" ? "active" : ""} onClick={(e) => this.subMenuAction('User Subjects')}><span className="submenu-logos"><FontAwesomeIcon icon={faUser} /></span>User Subjects</li>
                    </ul>
                </li>
                <li className={this.props.activeMenu === "Blog Posts" ? "active" : ""} onClick={(e) => this.subMenuAction('Blog Posts')}><span className="submenu-logos"><FontAwesomeIcon icon={faBlog} /></span>Blog Posts</li>
                <li className={this.props.activeMenu === "Subscriptions" ? "active" : ""} onClick={(e) => this.subMenuAction('Subscriptions')}><span className="submenu-logos"><FontAwesomeIcon icon={faUsers} /></span>Subscriptions</li>
                <li className={this.props.activeMenu === "Chats" ? "active" : ""} onClick={(e) => this.subMenuAction('Chats')}><span className="submenu-logos"><FontAwesomeIcon icon={faUsers} /></span>Chats</li>
                <li className={this.props.activeMenu === "Accounts" ? "active nonSubMenu" : ""} onClick={(e) => this.subMenuAction('Accounts')}><span className="submenu-logos"><FontAwesomeIcon icon={faUsers} /></span>Accounts <span className="arrow"><FontAwesomeIcon icon={faAngleLeft} /></span>
                    <ul className="foldableMenu m2">
                        <li className={this.props.activeMenu === "Subscriptions Subjects" ? "active" : ""} onClick={(e) => this.subMenuAction('Subscriptions')}><span className="submenu-logos"><FontAwesomeIcon icon={faUser} /></span>Subscriptions</li>
                        <li className={this.props.activeMenu === "Schedules Subjects" ? "active" : ""} onClick={(e) => this.subMenuAction('Schedules')}><span className="submenu-logos"><FontAwesomeIcon icon={faUser} /></span>Schedules</li>
                    </ul>
                </li>
                <li className={this.props.activeMenu === "Settings" ? "active" : ""} onClick={(e) => this.subMenuAction('Settings')}><span className="submenu-logos"><FontAwesomeIcon icon={faUsers} /></span>Settings</li>
            </ul>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(SubMenu);