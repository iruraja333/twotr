import React, { Component } from 'react';

import { connect } from 'react-redux';

class UsernameTextbox extends Component {
    constructor() {
        super();
        this.state = {
            layout: ""
        }
    }

    textBlur() {
        this.setState({ layout: "" });
    }

    textChange(e) {
        this.props.onChange(e);
    }

    textFocus() {
        this.setState({ layout: "focused" });
    }
    render() {

        return (
            <div className="formContainer" >
                <label className={`borderLayout ${this.state.layout}`} style={this.props.style}>
                    <img src={this.state.layout == "focused" ? 'images/uALogo.png' : 'images/ulogo.png'} alt="username logo" />
                    <input type="text" name={this.props.name} placeholder={this.props.placeholder} onFocus={(e) => this.textFocus()} onBlur={(e) => this.textBlur()} onChange={(e) => this.textChange(e)} value={this.props.value} />
                </label>
                <br />
                <p className="errormsg"></p> 
            </div>
        );
    }
}

export default UsernameTextbox;