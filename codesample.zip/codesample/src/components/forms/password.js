import React, { Component } from 'react';

import { connect } from 'react-redux';

class PasswordTextbox extends Component {
    constructor() {
        super();
        this.state = {
            layout: ""
        }
    }

    textBlur() {
        this.setState({ layout: "" });
    }

    textFocus() {
        this.setState({ layout: "focused" });
    }
    textChange(e) {
        this.props.onChange(e);
    }

    render() {
        return (
            <div className="formContainer">
                <label className={`borderLayout ${this.state.layout}`}  style={this.props.style}>
                    <img src={this.state.layout == "focused" ? 'images/pALogo.png' : 'images/plogo.png'} alt="username logo" />
                    <input type="password" placeholder={this.props.placeholder} onFocus={(e) => this.textFocus()} onChange={(e) => this.textChange(e)} value={this.props.value} onBlur={(e) => this.textBlur()} />
                </label>
                <br />
                <p className="errormsg"></p>
            </div>
        );
    }
}

export default PasswordTextbox;