import React, { Component } from 'react';

import { connect } from 'react-redux';

class Textbox extends Component {
    constructor() {
        super();
        this.state = {
            error: "",
        }
    }

    textBlur() {
        this.setState({ layout: "" });
    }


    textFocus() {
        this.setState({ layout: "focused" });
    }

    textChange(e) {
        this.props.onChange(e);
    }

    keyDown(e) {
        this.props.onKeyDown(e);
    }

    render() {

        return (
            <div className="textboxField" style={this.props.styleDiv}>

                <label htmlFor="">{this.props.label}</label>
                {this.props.label && <br />}
                <input type="text" disabled={this.props.disable} style={this.props.style} className={this.props.className} placeholder={this.props.placeholder} onKeyDown={(e) => this.keyDown(e)} onChange={(e) => this.textChange(e)} value={this.props.value} onFocus={(e) => this.textFocus()} onBlur={(e) => this.textBlur()} />
                {this.props.toolIcon && <span> <img height="25px" src="images/info.png"/></span>}
                <br />
                <span>{this.state.error}</span>
            </div>
        );
    }
}

export default Textbox;