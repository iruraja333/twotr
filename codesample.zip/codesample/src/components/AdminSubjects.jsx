import React, { Component } from 'react';
import { connect } from 'react-redux';
import List from './listview/List';
import { ADMINUSERLIST, ADDTITLE } from '../api/api';
import { call } from '../service/service';
import * as constant from '../constant/constant';

function mapStateToProps(state) {
    return {
        adminUserData: state.USERSUBJECTS,
        loading: state.ACTIONS.loading,
        userApprove: state.USERAPPROVE
    };
}

function mapDispatchToProps(dispatch) {
    return {
        fetchTutor: (data, loader) => {
            dispatch({ type: constant.loading, payload: loader || 1 });
            dispatch(call(data))
        },
        getUserDetails: (data) => {
            dispatch(call(data))
        },
        setLoader: (val) => {
            dispatch({ type: constant.loading, payload: val });
        }
    };
}

class AdminSubjects extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            totalRecords: 0,
            editView: false
        }
    }

    fetchData(page = 1, size = 10, params) {
        var { queryParams } = ADMINUSERLIST;
        queryParams.page = page;
        queryParams.size = size;
        ADMINUSERLIST.url = "https://api.twotr.com/api/admin/subject/list"

        ADMINUSERLIST.queryParams = queryParams;
        if (params)
            ADMINUSERLIST.params = null;
        this.props.fetchTutor(ADMINUSERLIST);
    }

    componentDidMount() {
        this.fetchData();
    }

    add() {
        this.setState({ editView: !this.state.editView })
    }

    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }

    addTitle() {
        this.props.setLoader(2);
        ADDTITLE.params.title = this.state.title;
        this.props.getUserDetails(ADDTITLE)

    }
    componentDidUpdate(prevProps) {
        if (prevProps.userApprove._id !== this.props.userApprove._id) {
            this.fetchData();
            this.setState({ editView: false, error: '' })
        }
        if (prevProps.userApprove.response !== this.props.userApprove.response) {
            if (this.props.userApprove.response)
                this.setState({ error: this.props.userApprove.response.data.message })
        }
    }

    render() {
        return (
            <div className="row">
                <div class="col-12">
                    <div class="page-title">
                        <div class="pull-left">
                            <h1 class="title">Admin Subjects</h1>
                        </div>
                        {!this.state.editView &&
                            <button className="p-btn disableBtn" onClick={(e) => this.add()}>
                                {this.props.loading === 2 ?
                                    <div className="btn-loader"></div>
                                    :
                                    <div>ADD</div>
                                }

                            </button>
                        }
                    </div>
                </div>
                {this.state.editView &&
                    <div className="col-12">
                        <div className="row table addTitle">
                            {this.state.error &&
                                <div className="col-10 errorMsg">
                                    {this.state.error}
                                </div>
                            }
                            <div className="col-4">
                                <div className="headerText">Title</div>
                                <input type="text" name="title" placeholder="Title" value={this.state.title} onChange={(e) => this.onChange(e)} />
                            </div>
                            <div className="col-4">

                                <button className="p-btn disableBtn" onClick={(e) => this.addTitle()}>
                                    {this.props.loading === 2 ?
                                        <div className="btn-loader"></div>
                                        :
                                        <div>ADD</div>
                                    }
                                </button>

                                <div className="col-2"></div>
                            </div>
                        </div>

                    </div>
                }
                {!this.state.editView &&
                    <div className="col-12">
                        {this.props.adminUserData.subjects && <List listType="adminsubject" loading={this.props.loading} sortData={ADMINUSERLIST.params.sort} fetchData={this.fetchData.bind(this)} data={this.props.adminUserData.subjects} totalCount={this.props.adminUserData.totalRecords}></List>}
                    </div>
                }
            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(AdminSubjects);
