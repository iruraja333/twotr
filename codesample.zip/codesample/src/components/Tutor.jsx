import React, { Component } from 'react';
import { connect } from 'react-redux';
import List from './listview/List';
import { TUTOR } from '../api/api';
import { call } from '../service/service';
import * as constant from '../constant/constant';

function mapStateToProps(state) {
  return {
    TutorData: state.TUTOR,
    loading: state.ACTIONS.loading
  };
}

function mapDispatchToProps(dispatch) {
  return {
    fetchTutor: (data, loader) => {
      dispatch({ type: constant.loading, payload: loader || 1 });
      dispatch(call(data))
    }
  };
}

class Tutor extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      totalRecords: 0
    }
  }

  fetchData(page = 1, size = 10, params) {
    var { queryParams } = TUTOR;
    queryParams.page = page;
    queryParams.size = size;

    TUTOR.queryParams = queryParams;
    if (params)
      TUTOR.params = { sort: params };
    this.props.fetchTutor(TUTOR);
  }

  componentDidMount() {
    this.fetchData();
  }
  download() {
    var download = TUTOR;
    download.url = "https://api.twotr.com/api/admin/print/user/tutor"
    download.type = "";
    this.props.fetchTutor(download, 2);
  }

  render() {
    return (
      <div className="row">
        <div class="col-12">
          <div class="page-title">
            <div class="pull-left">
              <h1 class="title">Tutors</h1>
            </div>
            <button className="p-btn disableBtn" onClick={(e) => this.download()}>
                            {this.props.loading === 2 ?
                                <div className="btn-loader"></div>
                                :
                                <div>Download</div>
                            }

                        </button>
          </div>
        </div>
        <div className="col-12">
          {this.props.TutorData.users && <List listType="user" loading={this.props.loading} sortData={TUTOR.params.sort} fetchData={this.fetchData.bind(this)} data={this.props.TutorData.users} totalCount={this.props.TutorData.totalRecords}></List>}
        </div>
      </div>
    );
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Tutor);
