import React, { Component } from 'react';
import { connect } from 'react-redux';
import * as constant from '../constant/constant';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBars } from '@fortawesome/free-solid-svg-icons'

function mapStateToProps(state) {
    return {
        smallMenu:state.ACTIONS.smallMenu
    };
}

function mapDispatchToProps(dispatch) {
    return {
        setSlideMenu: (val) => {
            dispatch({ type: constant.smallMenu, payload: val })
        },
        setActiveMenu: (val) => {
            dispatch({ type: constant.activeMenu, payload: val })
        }
    };
}

class Header extends Component {
    slideMenu = (e) => {
        this.props.setSlideMenu(!this.props.smallMenu);
    }
    render() {
        return (
            <div className="Header-Menu">
                <ul>
                    <li className={`logo ${this.props.smallMenu?"small":"big"}`}>

                    </li>
                    <li on onClick={(e) => this.slideMenu(e)}>
                    <FontAwesomeIcon icon={faBars} />
                    </li>
                </ul>

            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Header);