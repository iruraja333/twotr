import React, {Component} from 'react';

import {Router,Route} from 'react-router';

import { Provider } from 'react-redux'

import { history, store } from '../store';
import Home from './Home';
import Login from './Login';

class App extends Component {
    render() {
        return ( 
             <Provider store={store}>
                <Router history={history}>
                    <React.Fragment>
                        <Route path="/twotr" component={Home}></Route> 
                        <Route path="/login" component={Login}></Route> 
                    </React.Fragment>
                </Router> 
            </Provider>
        );
    }
}

export default App;