import React, { Component } from 'react';
import { connect } from 'react-redux';
import List from './listview/List';
import { ADMIN } from '../api/api';
import { call } from '../service/service';
import * as constant from '../constant/constant';

function mapStateToProps(state) {
    return {
        adminData: state.ADMIN,
        loading: state.ACTIONS.loading
    };
}

function mapDispatchToProps(dispatch) {
    return {
        fetchTutor: (data, loader) => {
            dispatch({ type: constant.loading, payload: loader || 1 });
            dispatch(call(data))
        }
    };
}

class Admin extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            totalRecords: 0
        }
    }

    fetchData(page = 1, size = 10, params) {
        var { queryParams } = ADMIN;
        queryParams.page = page;

        ADMIN.queryParams = queryParams;
        if (params)
            ADMIN.params = { sort: params };
        this.props.fetchTutor(ADMIN);
    }

    componentDidMount() {
        this.fetchData();
    }

    onDropChange(e) {
        var adminapi = ADMIN;
        if (e.target.value == 1)
            adminapi.url = "https://api.twotr.com/api/admin/users/admin/list/subadmin";
        else
            adminapi.url = "https://api.twotr.com/api/admin/users/admin/list/admin";
        this.props.fetchTutor(adminapi);
    }

    render() {
        return (
            <div className="row">
                <div class="col-12">
                    <div class="page-title">
                        <div class="pull-left">
                            <h1 class="title">Students</h1>
                        </div>
                        <select className="dropDown-menu pullRight" onChange={(e) => this.onDropChange(e)}>
                            <option value="2">Admin</option>
                            <option value="1">Sub Admin</option>
                        </select>
                    </div>
                </div>
                <div className="col-12">
                    {this.props.adminData.users && <List listType="admin" loading={this.props.loading} sortData={ADMIN.params.sort} fetchData={this.fetchData.bind(this)} data={this.props.adminData.users} totalCount={this.props.adminData.totalRecords}></List>}
                </div>
            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Admin);
