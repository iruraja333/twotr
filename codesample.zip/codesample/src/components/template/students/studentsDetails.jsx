import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheck, faTimes, faAngleLeft, faReply, faUser } from '@fortawesome/free-solid-svg-icons'
import { history } from "../../../store";
import { STATUSUPDATE } from '../../../api/api';
import * as constant from '../../../constant/constant';
import { call } from '../../../service/service';

function mapStateToProps(state) {
    return {
        getUserDetailRes: state.GETUSERDETAILS,
        loading:state.ACTIONS.loading,
        updateResult: state.STATUSUPDATE
    };
}

function mapDispatchToProps(dispatch) {
    return {
        setLoader: (val) => {
            dispatch({ type: constant.loading, payload: val });
        },updateStatus: (data) => {
            dispatch(call(data))
        }
    };
}

class StudentsDetails extends Component {
    state = {
        accordionIndex: []
    }
    activeAccordion(index) {
        var accordionIndex = this.state.accordionIndex;
        accordionIndex[index] = !accordionIndex[index];
        this.setState({ accordionIndex: accordionIndex })
    }
    backToList(e) {
        history.push("/twotr/students");
    }
    download(path) {
        window.open("http://admin.twotr.com/files/" + path, "_blank")
    }
    loadDegree(items) {
        return items.map((v, k) => {
            return <div key={k} className="col-4 itemFContainer">
                <div>
                    <div className="headerText">Degree-{k + 1}</div>
                    <div>
                        {
                            Object.keys(v).map((val, key) => {
                                return <div key={key}>{val} : {items[0][val]}</div>
                            })
                        }
                    </div>
                </div>
            </div>


        })
    }
    loadActive(flag) {
        return <FontAwesomeIcon className={flag ? "active" : "inActive"} icon={flag ? faCheck : faTimes} />
    }
    updateStatus(id, activate) {

        this.props.setLoader(2);
        const UPDATEAPI = STATUSUPDATE;
        UPDATEAPI.params.activate = !activate;
        UPDATEAPI.url = "https://api.twotr.com/api/admin/users/activate/" + id;
        this.props.updateStatus(UPDATEAPI)
    }
    componentDidUpdate(nextProps){
        if (nextProps.updateResult.message == "User active status updated.") {
            history.push("/twotr/students");
        }
        return null;
    }
    render() {
        return (
            <React.Fragment>
                <div className="row" style={{ marginTop: '15px' }}>
                    <div className="col-12">
                        <FontAwesomeIcon className="backBtn" icon={faReply} onClick={(e) => this.backToList(e)} />
                        <button className="p-btn disableBtn" onClick={(e) => this.updateStatus(this.props.getUserDetailRes._id, this.props.getUserDetailRes.isActive)}>
                            {this.props.loading === 2 ?
                                <div className="btn-loader"></div>
                                :
                                this.props.getUserDetailRes.isActive?<div>Disable</div>:<div>Enable</div>
                            }

                        </button>
                    </div>
                </div>
                <div className="row table" style={{ marginTop: '15px' }}>
                    <div className="col-4">
                        {this.props.getUserDetailRes.profilePicture ?
                            <img src={"https://api.twotr.com/files/" + this.props.getUserDetailRes.profilePicture.url} height="100px" style={{ padding: '10px' }} />
                            :
                            <FontAwesomeIcon className="profileIcon" icon={faUser} />
                        }
                        <h5>{this.props.getUserDetailRes.firstName}</h5>
                        <span>{this.props.getUserDetailRes.roles.join(',')}</span>
                    </div>
                    <div className="col-4 itemContainer">
                        <div>
                            <div className="headerText">Email</div>
                            <div>{this.props.getUserDetailRes.email}</div>
                        </div>
                        <div>
                            <div className="headerText">Created At</div>
                            <div>{this.props.getUserDetailRes.createdAt}</div>
                        </div>
                    </div>
                    <div className="col-4 itemContainer">
                        <div>
                            <div className="headerText">Referral Code</div>
                            <div>{this.props.getUserDetailRes.referralCode}</div>
                        </div>
                        <div className="itemFContainer">
                            <div className="headerText">Status : <FontAwesomeIcon className={this.props.getUserDetailRes.isActive ? "active" : "inActive"} icon={this.props.getUserDetailRes.isActive ? faCheck : faTimes} /></div>
                        </div>
                    </div>
                    <div className="col-4 itemFContainer"><span className="headerText">Email Verified</span> : <FontAwesomeIcon className={this.props.getUserDetailRes.verification.isEmailVerified ? "active" : "inActive"} icon={this.props.getUserDetailRes.verification.isEmailVerified ? faCheck : faTimes} /></div>
                    <div className="col-4 itemFContainer"><span className="headerText">Mobile Verified</span> : <FontAwesomeIcon className={this.props.getUserDetailRes.verification.isMobileVerified ? "active" : "inActive"} icon={this.props.getUserDetailRes.verification.isMobileVerified ? faCheck : faTimes} /></div>
                    <div className="col-4 itemFContainer"><span className="headerText">Profile Completed</span> : <FontAwesomeIcon className={this.props.getUserDetailRes.verification.isProfileCompleted ? "active" : "inActive"} icon={this.props.getUserDetailRes.verification.isProfileCompleted ? faCheck : faTimes} /></div>
                </div>
                <div className="row accordion table" onClick={(e) => this.activeAccordion(0)}>
                    <div className={this.state.accordionIndex[0] ? "col-12 headerText head active" : "col-12 headerText head"} >
                        ID Verifications
                        <span className="arrow"><FontAwesomeIcon icon={faAngleLeft} /></span>
                    </div>
                    <div className={this.state.accordionIndex[0] ? "col-12 accordionDetail" : "col-12 accordionDetail non-activeAccordion"}>
                        <div className="row">
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Document Number</div>
                                    <div>{this.props.getUserDetailRes.idVerification.documentNumber || "Not Yet Verified"}</div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Document Type</div>
                                    <div>{this.props.getUserDetailRes.idVerification.documentType || "Not Yet Verified"}</div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Zone</div>
                                    <div>{this.props.getUserDetailRes.idVerification.zone || "Not Yet Verified"}</div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Certificates</div>
                                    {
                                        this.props.getUserDetailRes.idVerification.certificates.map((v, k) => {
                                            return <div onClick={(e) => this.download(v.url)} key={k}>{v.name}</div>
                                        })
                                    }

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row accordion table" onClick={(e) => this.activeAccordion(1)}>
                    <div className={this.state.accordionIndex[1] ? "col-12 headerText head active" : "col-12 headerText head"} >
                        Profile Info
                        <span className="arrow"><FontAwesomeIcon icon={faAngleLeft} /></span>
                    </div>
                    <div className={this.state.accordionIndex[1] ? "col-12 accordionDetail" : "col-12 accordionDetail non-activeAccordion"}>
                        <div className="row">
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Can Teach?</div>
                                    <div><FontAwesomeIcon className={this.props.getUserDetailRes.profileInfo.canTutor ? "active" : "inActive"} icon={this.props.getUserDetailRes.profileInfo.canTutor ? faCheck : faTimes} /></div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Description</div>
                                    <div>{this.props.getUserDetailRes.profileInfo.description}</div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Grade Level</div>
                                    <div>{this.props.getUserDetailRes.profileInfo.gradeLevel.join(",")}</div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Mobile Number</div>
                                    <div>{this.props.getUserDetailRes.profileInfo.mobileNumber.number}</div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Default Country</div>
                                    <div>{this.props.getUserDetailRes.profileInfo.defaultCountry}</div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Timezone</div>
                                    <div>{this.props.getUserDetailRes.profileInfo.timezone}</div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Gender</div>
                                    <div>{this.props.getUserDetailRes.profileInfo.gender}</div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">DOB</div>
                                    <div>{this.props.getUserDetailRes.profileInfo.dob}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row accordion table" onClick={(e) => this.activeAccordion(2)}>
                    <div className={this.state.accordionIndex[2] ? "col-12 headerText head active" : "col-12 headerText head"} >
                        Educational Info
                        <span className="arrow"><FontAwesomeIcon icon={faAngleLeft} /></span>
                    </div>
                    <div className={this.state.accordionIndex[2] ? "col-12 accordionDetail" : "col-12 accordionDetail non-activeAccordion"}>
                        <div className="row">
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Is Certified Tutor?</div>
                                    <div><FontAwesomeIcon className={this.props.getUserDetailRes.educationInfo.isCertifiedTutor ? "active" : "inActive"} icon={this.props.getUserDetailRes.educationInfo.isCertifiedTutor ? faCheck : faTimes} /></div>
                                </div>
                            </div>
                            {this.loadDegree(this.props.getUserDetailRes.educationInfo.degrees)}

                        </div>
                    </div>
                </div>
                <div className="row accordion table" onClick={(e) => this.activeAccordion(3)}>
                    <div className={this.state.accordionIndex[3] ? "col-12 headerText head active" : "col-12 headerText head"} >
                        Teaching Info - Not Verified
                        <span className="arrow"><FontAwesomeIcon icon={faAngleLeft} /></span>
                    </div>
                    <div className={this.state.accordionIndex[3] ? "col-12 accordionDetail" : "col-12 accordionDetail non-activeAccordion"}>
                        <div className="row">
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Year</div>
                                    <div></div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Has Expiry</div>
                                    <div>{this.loadActive(this.props.getUserDetailRes.teachingInfo.hasExpiry)}</div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Issue Date</div>
                                    <div></div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Expiry Date</div>
                                    <div></div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Grade Level</div>
                                    <div></div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Field of Study</div>
                                    <div></div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Subject Area</div>
                                    <div></div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Certificate Name</div>
                                    <div></div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Certificates</div>
                                    <div></div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Education Type</div>
                                    <div></div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Institution</div>
                                    <div></div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Issuing Country</div>
                                    <div></div>
                                </div>
                            </div>
                            <div className="col-4 itemFContainer">
                                <div>
                                    <div className="headerText">Issuing Body</div>
                                    <div></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </React.Fragment>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(StudentsDetails);