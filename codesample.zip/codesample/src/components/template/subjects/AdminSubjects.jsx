import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faUserEdit, faThumbsUp, faThumbsDown, faChevronCircleRight, faSave } from '@fortawesome/free-solid-svg-icons'
import * as constant from '../../../constant/constant';
import { TITLEUPDATE } from '../../../api/api';
import { call } from '../../../service/service';
function mapStateToProps(state) {
    return {
        loading: state.ACTIONS.loading,
        userApprove: state.USERAPPROVE
    };
}

function mapDispatchToProps(dispatch) {
    return {
        setEditLoad: (val) => {
            dispatch({ type: constant.editLoading, payload: val })
        },
        setLoader: (val) => {
            dispatch({ type: constant.loading, payload: val });
        }, 
        serviceCall: (data) => {
            dispatch(call(data))
        },
    };
}

class AdminSubjects extends Component {
    state = {
        editIndex: -1,
        editTitle: ''
    }
    edit(edit, initValue) {
        this.setState({ editIndex: edit, editTitle: initValue });
        if (edit == -1)
            this.props.setEditLoad(false);
        else
            this.props.setEditLoad(true);
    }
    save(id) {
        this.props.setLoader(2);
        TITLEUPDATE.params.id = id;
        TITLEUPDATE.params.title = this.state.editTitle;
        this.props.serviceCall(TITLEUPDATE)
    }
 

    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }

    loadData() {
        return this.props.data.map((val, key) => {
            return <div key={key} className={`row ${key == this.state.editIndex ? "update-view" : ""}`}>

                {key == this.state.editIndex ?
                    <div className="col-6"><input onChange={(e) => this.onChange(e)} className="lorgeEditText" name="editTitle" value={this.state.editTitle} type="text" placeholder="0" /></div>
                    :
                    <div className="col-6">{val.title}</div>
                }
                
                {key == this.state.editIndex ?
                    <div className="col-4">
                        {
                            this.props.loading === 2 && this.state.editIndex === key ?
                                <div className="btn-loader editLoader"></div>
                                :
                                <FontAwesomeIcon onClick={(e) => this.save(val._id)} className="actionIcon" icon={faSave} />
                        }
                        <FontAwesomeIcon onClick={(e) => this.edit(-1, '')} className="actionIcon" icon={faChevronCircleRight} />
                    </div>
                    :
                    <div className="col-4">
                        <FontAwesomeIcon onClick={(e) => this.edit(key, val.title)} className="actionIcon" icon={faUserEdit} />
                    </div>
                }


            </div>
        })
    }


    componentDidUpdate(prevProps) {
        if (prevProps.userApprove._id != this.props.userApprove._id) {
            this.props.fetchData(this.props.page, this.props.size)
            this.edit(-1,'')
        }
    }

    render() {
        return (
            <div className={`table ${this.props.loading === 1 && "loader"}`}>
                <div className="header">
                    <div className="row">
                        <div className="col-6"> Title </div>
                        <div className="col-4">Actions</div>
                    </div>
                </div>
                <div className="body">
                    {this.loadData()}
                </div>
            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(AdminSubjects);