import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faUserEdit, faThumbsUp, faThumbsDown, faChevronCircleRight, faSave } from '@fortawesome/free-solid-svg-icons'
import * as constant from '../../../constant/constant';
import { USERAPPROVE, GETUSERDETAILS } from '../../../api/api';
import { call } from '../../../service/service';
import { history } from "../../../store";
function mapStateToProps(state) {
    return {
        loading: state.ACTIONS.loading,
        userApprove: state.USERAPPROVE
    };
}

function mapDispatchToProps(dispatch) {
    return {
        setEditLoad: (val) => {
            dispatch({ type: constant.editLoading, payload: val })
        },
        resetUpdateResult: (val) => {
            dispatch({ type: constant.UPDATEREFPOINT, payload: {} })
        },
        updateRefPoint: (data) => {
            dispatch(call(data))
        },
        getUserDetails: (data) => {
            dispatch(call(data))
        },
        setLoader: (val) => {
            dispatch({ type: constant.loading, payload: val });
        },
        getPermission: (data) => {
            dispatch(call(data))
        }
    };
}

class UserSubjects extends Component {
    state = {
        editIndex: -1,
        editTitle: ''
    }
    edit(edit, initValue) {
        this.setState({ editIndex: edit, editTitle: initValue });
        if (edit == -1)
            this.props.setEditLoad(false);
        else
            this.props.setEditLoad(true);
    }

    updateStatus(id, status, index) {
        this.setState({editIndex:index})
        this.props.setLoader(2);
        USERAPPROVE.params.id = id;
        USERAPPROVE.params.isApproved = !status;
        this.props.getUserDetails(USERAPPROVE)
    }

    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }

    loadData() {
        return this.props.data.map((val, key) => {
            return <div key={key} className={`row ${key == this.state.editIndex ? "update-view" : ""}`}>
                <div className="col-4">{val.title}</div>
                <div className="col-4">{val.isApproved ? "Approved" : "Not Approved"}</div>
                <div className="col-4">
                    {
                        this.props.loading === 2 && this.state.editIndex === key ?
                            <div className="btn-loader editLoader"></div>
                            :
                            <FontAwesomeIcon onClick={(e) => this.updateStatus(val._id, val.isApproved, key)} className={val.isApproved ? "actionIcon inActive" : "actionIcon active"} icon={val.isApproved ? faThumbsDown : faThumbsUp} />
                    }

                </div>



            </div>
        })
    }


    componentDidUpdate(prevProps) {
        if (prevProps.userApprove._id !== this.props.userApprove._id) {
            this.props.fetchData(this.props.page, this.props.size)
        }
    }

    render() {
        return (
            <div className={`table ${this.props.loading === 1 && "loader"}`}>
                <div className="header">
                    <div className="row">
                        <div className="col-4"> Title </div>
                        <div className="col-4"> Status </div>
                        <div className="col-4"></div>
                    </div>
                </div>
                <div className="body">
                    {this.loadData()}
                </div>
            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(UserSubjects);