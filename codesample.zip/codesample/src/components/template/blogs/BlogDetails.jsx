import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheck, faTimes, faAngleLeft, faReply, faUser } from '@fortawesome/free-solid-svg-icons'
import { history } from "../../../store";
import * as constant from '../../../constant/constant';
import { call } from '../../../service/service';
import { BLOGUPDATE } from '../../../api/api';

function mapStateToProps(state) {
    return {
        getBlogDetailRes: state.UPDATEDETAILS,
        loading: state.ACTIONS.loading
    };
}

function mapDispatchToProps(dispatch) {
    return {
        setLoader: (val) => {
            dispatch({ type: constant.loading, payload: val });
        }, update: (data) => {
            dispatch(call(data))
        }
    };
}

class BlogDetails extends Component {
    state = {

    }
    backToList(e) {
        history.push("/twotr/blogs");
    }
    updateStatus(id, activate) {


    }
    componentDidMount() {
        if (this.props.getBlogDetailRes && this.props.getBlogDetailRes.title)
            this.setState(this.props.getBlogDetailRes);
    }
    componentDidUpdate(nextProps) {
        if (nextProps.loading === 2 && nextProps.loading === this.props.loading) {
            history.push("/twotr/blogs");
        }

        if (nextProps.getBlogDetailRes.title !== this.props.getBlogDetailRes.title) {
            this.setState(this.props.getBlogDetailRes);
        }
        return null;
    }
    onchange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }
    loadImage = () => {
        if (this.props.getBlogDetailRes.title) {
            return this.props.getBlogDetailRes.picture.map((v, i) => {
                return <img className="img" src={"https://api.twotr.com/files/" + v.url} alt="" />
            });
        }
        return "";
    }
    save = (id) => {
        this.props.setLoader(2);
        BLOGUPDATE.params = this.state;
        if (this.state._id) {
            BLOGUPDATE.url = "https://api.twotr.com/api/admin/blogpost/update/" + this.props.getBlogDetailRes._id;
        } else {
            BLOGUPDATE.url = "https://api.twotr.com/api/admin/blogpost/create";
        }
        this.props.update(BLOGUPDATE)
    }

    isUpdate() {
        return this.props.location.pathname === "/twotr/blogUpdate" && this.state.title;
    }
    render() {
        return (
            <React.Fragment>
                <div className="row" style={{ marginTop: '15px' }}>
                    <div className="col-12">
                        <FontAwesomeIcon className="backBtn" icon={faReply} onClick={(e) => this.backToList(e)} />
                    </div>
                </div>
                <div className="row table form-container" style={{ marginTop: '15px' }}>
                    <div className="col-6">
                        <div className="headerText">Title</div>
                        <div>
                            <input type="text" placeholder="Title" name="title" value={this.state.title} onChange={(e) => this.onchange(e)} />
                        </div>
                    </div>

                    <div className="col-6">
                        <div className="headerText">Link Text</div>
                        <input type="text" placeholder="Link Text" name="linkText" value={this.state.linkText} onChange={(e) => this.onchange(e)} />
                    </div>
                    <div className="col-6">
                        <div className="headerText">Video URL</div>
                        <input type="text" placeholder="Video URL" name="videoUrl" value={this.state.videoUrl} onChange={(e) => this.onchange(e)} />
                    </div>
                    <div className="col-6">
                        <div className="headerText">link URL</div>
                        <input type="text" placeholder="Link URL" name="linkUrl" value={this.state.videoUrl} onChange={(e) => this.onchange(e)} />
                    </div>
                    <div className="col-6">
                        <div className="headerText">Images</div>
                        {this.loadImage()}
                    </div>
                    <div className="col-12">
                        <div className="headerText">Description</div>
                        <textarea className="textArea" type="text" placeholder="Description" name="description" value={this.state.description} onChange={(e) => this.onchange(e)} />
                    </div>
                    {this.isUpdate() &&
                        <div className="col-12 submitBlogs">
                            <button className="p-btn disableBtn" onClick={(e) => this.save(e)}>
                                {this.props.loading === 2 ?
                                    <div className="btn-loader"></div>
                                    :
                                    <div>Submit</div>
                                }

                            </button>
                        </div>
                    }
                </div>

            </React.Fragment>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(BlogDetails);