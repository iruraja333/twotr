import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBookOpen, faTrash, faUserEdit } from '@fortawesome/free-solid-svg-icons'
import * as constant from '../../../constant/constant';
import { GETUSERBLOGDETAILS, DELETEBLOG } from '../../../api/api';
import { call } from '../../../service/service';
import { history } from "../../../store";
function mapStateToProps(state) {
    return {
        getBlogDetailRes: state.UPDATEDETAILS,
        loading: state.ACTIONS.loading
    };
}

function mapDispatchToProps(dispatch) {
    return {
        setEditLoad: (val) => {
            dispatch({ type: constant.editLoading, payload: val })
        },
        resetUpdateResult: (val) => {
            dispatch({ type: constant.UPDATEREFPOINT, payload: {} })
        },
        update: (data) => {
            dispatch(call(data))
        },
        getDetails: (data) => {
            dispatch(call(data))
        },
        setLoader: (val) => {
            dispatch({ type: constant.loading, payload: val });
        }
    };
}

class Blogs extends Component {
    state = {
        isUpdate: false
    }

    view(id) {
        this.setState({ isUpdate: false });
        GETUSERBLOGDETAILS.url = 'https://api.twotr.com/api/admin/blogpost/' + id;
        this.props.getDetails(GETUSERBLOGDETAILS)
    }

    edit(id) {
        this.setState({ isUpdate: true })
        GETUSERBLOGDETAILS.url = 'https://api.twotr.com/api/admin/blogpost/' + id;
        this.props.getDetails(GETUSERBLOGDETAILS)
    }

    delete(id) {
        DELETEBLOG.url = 'https://api.twotr.com/api/admin/blogpost/delete/' + id;
        this.props.getDetails(DELETEBLOG);
    }

    loadData() {
        return this.props.data.map((val, key) => {
            return <div key={key} className={`row ${key == this.state.editIndex ? "update-view" : ""}`}>
                <div className="col-2 elipse">{val.title}</div>
                <div className="col-3 elipse">{val.linkText}</div>
                <div className="col-2 elipse">{val.linkUrl}</div>
                <div className="col-3 elipse">{val.videoUrl}</div>

                <div className="col-2 elipse">
                    <FontAwesomeIcon onClick={(e) => this.view(val._id)} className="actionIcon" icon={faBookOpen} />
                    <FontAwesomeIcon onClick={(e) => this.edit(val._id)} className="actionIcon" icon={faUserEdit} />
                    <FontAwesomeIcon onClick={(e) => this.delete(val._id)} className="actionIcon" icon={faTrash} />
                </div>

            </div>
        })
    }

    componentDidUpdate(prevProps) {
        if (prevProps.getBlogDetailRes._id !== this.props.getBlogDetailRes._id) {
            if (this.props.getBlogDetailRes.message == "Blog post deleted successfully.") {
                this.props.fetchData(this.props.page, this.props.size);
            } else
                if (this.state.isUpdate)
                    history.push("/twotr/blogUpdate");
                else
                    history.push("/twotr/blogDetails");
        }
    }

    render() {
        return (
            <div className={`table ${this.props.loading === 1 && "loader"}`}>
                <div className="header">
                    <div className="row">
                        <div className="col-2"> Title </div>
                        <div className="col-3"> Link Text</div>
                        <div className="col-2"> Link URL</div>
                        <div className="col-3">Video URL</div>
                        <div className="col-2">Actions</div>
                    </div>
                </div>
                <div className="body">
                    {this.loadData()}
                </div>
            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Blogs);