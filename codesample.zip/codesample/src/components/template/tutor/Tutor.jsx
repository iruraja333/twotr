import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faSortAlphaDown, faSortAlphaUp, faCheck, faTimes, faUserEdit, faBookOpen, faSave, faChevronCircleRight } from '@fortawesome/free-solid-svg-icons'
import * as constant from '../../../constant/constant';
import { UPDATEREFERPOINT, GETUSERDETAILS } from '../../../api/api';
import { call } from '../../../service/service';
import { history } from "../../../store";
function mapStateToProps(state) {
    return {
        updateResult: state.UPDATEREFPOINT,
        getUserDetailRes: state.GETUSERDETAILS,
        loading: state.ACTIONS.loading
    };
}

function mapDispatchToProps(dispatch) {
    return {
        setEditLoad: (val) => {
            dispatch({ type: constant.editLoading, payload: val })
        },
        resetUpdateResult: (val) => {
            dispatch({ type: constant.UPDATEREFPOINT, payload: {} })
        },
        updateRefPoint: (data) => {
            dispatch(call(data))
        },
        getUserDetails: (data) => {
            dispatch(call(data))
        },
        setLoader: (val) => {
            dispatch({ type: constant.loading, payload: val });
        }
    };
}

class TutorTemplate extends Component {
    state = {
        editIndex: -1,
        editRefPoint: ''
    }
    edit(edit, initValue) {
        this.setState({ editIndex: edit, editRefPoint: initValue });
        if (edit == -1)
            this.props.setEditLoad(false);
        else
            this.props.setEditLoad(true);
    }
    save(id) {
        this.props.setLoader(2);
        const UPDATEAPI = UPDATEREFERPOINT;
        UPDATEAPI.params.points = this.state.editRefPoint;
        UPDATEAPI.url = UPDATEREFERPOINT.url + id;
        this.props.updateRefPoint(UPDATEAPI)
    }
    getDetails(id) {
        const GETUSERDETAILSAPI = GETUSERDETAILS;
        GETUSERDETAILSAPI.url = 'https://api.twotr.com/api/admin/users/get/' + id;
        this.props.getUserDetails(GETUSERDETAILSAPI)
    }

    loadData() {
        return this.props.data.map((val, key) => {
            return <div key={key} className={`row ${key == this.state.editIndex ? "update-view" : ""}`}>
                <div className="col-2">{val.firstName}</div>
                <div className="col-3">{val.email}</div>
                <div className="col-3">{val.createdAt}</div>
                {key == this.state.editIndex ?
                    <div className="col-1"><input onChange={(e) => this.onChange(e)} className="editText" name="editRefPoint" value={this.state.editRefPoint} type="text" placeholder="0" /></div>
                    :
                    <div className="col-1">{val.referralPoints}</div>
                }

                <div className="col-1"><FontAwesomeIcon className={val.isActive ? "active" : "inActive"} icon={val.isActive ? faCheck : faTimes} /></div>
                {key == this.state.editIndex ?
                    <div className="col-1">
                        {
                            this.props.loading === 2 ?
                                <div className="btn-loader editLoader"></div>
                                :
                                <FontAwesomeIcon onClick={(e) => this.save(val._id)} className="actionIcon" icon={faSave} />
                        }

                        <FontAwesomeIcon onClick={(e) => this.edit(-1, '')} className="actionIcon" icon={faChevronCircleRight} />
                    </div>
                    :
                    <div className="col-1">
                        <FontAwesomeIcon onClick={(e) => this.edit(key, val.referralPoints)} className="actionIcon" icon={faUserEdit} />
                        <FontAwesomeIcon onClick={(e) => this.getDetails(val._id)} className="actionIcon" icon={faBookOpen} />
                    </div>
                }
            </div>
        })
    }

    sorting(index) {
        var direction = this.props.sortData[index]["direction"];
        var sortData = this.props.sortData;
        if (direction == "none" || direction == "desc")
            sortData[index]["direction"] = "asc";
        else
            sortData[index]["direction"] = "desc";

        this.props.fetchData(this.props.page, this.props.size, sortData);
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        if (nextProps.updateResult.message == "Points updated successfully.") {
            prevState.editIndex = -1;
            prevState.editRefPoint = '';
            nextProps.setEditLoad(false);
            nextProps.resetUpdateResult();
            nextProps.fetchData(nextProps.page, nextProps.size, nextProps.sortData);
        }
        return null;
    }
    componentDidUpdate(prevProps) {
        if (prevProps.getUserDetailRes._id !== this.props.getUserDetailRes._id) {
            history.push("/twotr/tutorDetails");
        }
    }
    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }

    render() {
        return (
            <div className={`table ${this.props.loading ===1 && "loader"}`}>
                <div className="header">
                    <div className="row">
                        <div className="col-2"><FontAwesomeIcon onClick={(e) => this.sorting(0)} className={this.props.sortData[0]["direction"] == "none" ? "noSort" : ""} icon={this.props.sortData[0]["direction"] == "desc" ? faSortAlphaUp : faSortAlphaDown} /> Name </div>
                        <div className="col-3"><FontAwesomeIcon onClick={(e) => this.sorting(1)} className={this.props.sortData[1]["direction"] == "none" ? "noSort" : ""} icon={this.props.sortData[1]["direction"] == "desc" ? faSortAlphaUp : faSortAlphaDown} /> Email</div>
                        <div className="col-3"><FontAwesomeIcon onClick={(e) => this.sorting(2)} className={this.props.sortData[2]["direction"] == "none" ? "noSort" : ""} icon={this.props.sortData[2]["direction"] == "desc" ? faSortAlphaUp : faSortAlphaDown} /> Created At</div>
                        <div className="col-1">Ref Points</div>
                        <div className="col-1">Status</div>
                        {/* <div className="col-1">Actions</div> */}
                    </div>
                </div>
                <div className="body">
                    {this.loadData()}
                </div>
            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(TutorTemplate);