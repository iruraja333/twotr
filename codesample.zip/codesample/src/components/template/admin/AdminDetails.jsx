import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheck, faTimes, faAngleLeft, faReply, faUser } from '@fortawesome/free-solid-svg-icons'
import { history } from "../../../store";
import * as constant from '../../../constant/constant';
import { call } from '../../../service/service';
import { STATUSUPDATE } from '../../../api/api';

function mapStateToProps(state) {
    return {
        getUserDetailRes: state.GETUSERDETAILS,
        updateResult: state.STATUSUPDATE,
        loading: state.ACTIONS.loading
    };
}

function mapDispatchToProps(dispatch) {
    return {
        setLoader: (val) => {
            dispatch({ type: constant.loading, payload: val });
        }, updateStatus: (data) => {
            dispatch(call(data))
        }
    };
}

class AdminDetails extends Component {
    state = {

    }
    backToList(e) {
        history.push("/twotr/admin");
    }
    updateStatus(id, activate) {

        this.props.setLoader(2);
        const UPDATEAPI = STATUSUPDATE;
        UPDATEAPI.params.activate = !activate;
        UPDATEAPI.url = "https://api.twotr.com/api/admin/users/activate/" + id;
        this.props.updateStatus(UPDATEAPI)
    }
    componentDidMount() {
        if (this.props.getUserDetailRes && this.props.getUserDetailRes.firstName)
            this.setState({
                firstname: this.props.getUserDetailRes.firstName,
                lastname: this.props.getUserDetailRes.lastName,
                email: this.props.getUserDetailRes.email,
                password: '',
            });
    }
    componentDidUpdate(nextProps) {
        if (nextProps.updateResult.message === "User active status updated.") {
            history.push("/twotr/admin");
        }

        if (nextProps.getUserDetailRes.firstName !== this.props.getUserDetailRes.firstName) {
            this.setState({
                firstname: this.props.getUserDetailRes.firstName,
                lastname: this.props.getUserDetailRes.lastName,
                email: this.props.getUserDetailRes.email,
                password: '',
            });
        }
        return null;
    }
    onchange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }
    onDropChange(e) {
        this.setState({ roles: e.target.value });
    }
    render() {
        return (
            <React.Fragment>
                <div className="row" style={{ marginTop: '15px' }}>
                    <div className="col-12">
                        <FontAwesomeIcon className="backBtn" icon={faReply} onClick={(e) => this.backToList(e)} />
                        <button className="p-btn disableBtn" onClick={(e) => this.download()}>
                            {this.props.loading === 2 ?
                                <div className="btn-loader"></div>
                                :
                                <div>Submit</div>
                            }

                        </button>
                    </div>
                </div>
                <div className="row table form-container" style={{ marginTop: '15px' }}>
                    <div className="col-6">
                        <div className="headerText">First Name</div>
                        <div>
                            <input type="text" placeholder="First Name" name="firstname" value={this.state.firstname} oncha={(e) => this.onchange(e)} />
                        </div>
                    </div>
                    <div className="col-6">
                        <div className="headerText">Last Name</div>
                        <input type="text" placeholder="Last Name" name="lastname" value={this.state.lastname} oncha={(e) => this.onchange(e)} />
                    </div>
                    <div className="col-6">
                        <div className="headerText">Email</div>
                        <input type="text" placeholder="Email" name="email" value={this.state.email} oncha={(e) => this.onchange(e)} />
                    </div>
                    <div className="col-6">
                        <div className="headerText">Roles</div>
                        <select className="dropDown-menu" value={this.state.roles} name="roles" onChange={(e) => this.onDropChange(e)}>
                            <option value="2">Admin</option>
                            <option value="1">Sub Admin</option>
                        </select>
                    </div>
                    <div className="col-6">
                        <div className="headerText">Password</div>
                        <input type="password" placeholder="Password" name="password" value={this.state.password} oncha={(e) => this.onchange(e)} />
                    </div>
                </div>

            </React.Fragment>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(AdminDetails);