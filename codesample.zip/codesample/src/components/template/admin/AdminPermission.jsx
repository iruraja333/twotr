import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faSortAlphaDown, faSortAlphaUp, faCheck, faTimes, faUserEdit, faBookOpen, faUserShield } from '@fortawesome/free-solid-svg-icons'
import * as constant from '../../../constant/constant';
import { UPDATEREFERPOINT, GETUSERDETAILS } from '../../../api/api';
import { call } from '../../../service/service';
import { history } from "../../../store";
function mapStateToProps(state) {
    return {
        loading: state.ACTIONS.loading,
        permission: state.PERMISSIONS
    };
}

function mapDispatchToProps(dispatch) {
    return {
        getUserDetails: (data) => {
            dispatch(call(data))
        },
        setLoader: (val) => {
            dispatch({ type: constant.loading, payload: val });
        }
    };
}

class AdminPermission extends Component {
    state = {
        editIndex: -1,
        editRefPoint: ''
    }

    loadData() {
        return JSON.parse(this.props.permission.permissions)
            .filter((v, i) => { return !v.parent })
            .sort((a, b) => { return a.order - b.order })
            .map((val, key) => {
                var array = JSON.parse(this.props.permission.permissions)
                    .filter((v, i) => { return val.key == v.parent });
                var arrayIndex = [...val.permission]
                if (array.length > 1) {
                    return array.map((item, index) => {
                        debugger;
                        var arrIndex = [...item.permission]
                        return <React.Fragment>
                            {index === 0 &&
                                <div className="row permission-title">
                                    <div className="col-6">{val.key}</div>
                                </div>
                            }
                            <div key={index} className="row">
                                <div className="col-6">{item.key}</div>
                                <div className="col-2"> {arrayIndex[0]=="1" ? <input type="checkbox" checked /> : <input type="checkbox" />}</div>
                                <div className="col-2">{arrayIndex[1]=="1" ? <input type="checkbox" checked /> : <input type="checkbox" />}</div>
                                <div className="col-2">{arrayIndex[2] =="1"? <input type="checkbox" checked /> : <input type="checkbox" />}</div>
                            </div>
                        </React.Fragment>
                    });
                }
                else
                    return <div key={key} className="row permission-title">
                        <div className="col-6">{val.key}</div>
                        <div className="col-2"> {arrayIndex[0]=="1" ? <input type="checkbox" checked /> : <input type="checkbox" />}</div>
                        <div className="col-2">{arrayIndex[1]=="1" ? <input type="checkbox" checked /> : <input type="checkbox" />}</div>
                        <div className="col-2">{arrayIndex[2]=="1" ? <input type="checkbox" checked /> : <input type="checkbox" />}</div>
                    </div>
            })
    }



    render() {
        return (
            <div className={`table ${this.props.loading === 1 && "loader"}`}>
                <div className="header">
                    <div className="row permission-header">
                        <div className="col-6">Permissions </div>
                        <div className="col-2">Read</div>
                        <div className="col-2">Update</div>
                        <div className="col-2">Delete</div>
                    </div>
                </div>
                <div className="body">
                    {this.loadData()}
                </div>
            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(AdminPermission);