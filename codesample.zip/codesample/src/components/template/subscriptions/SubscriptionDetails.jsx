import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheck, faTimes, faAngleLeft, faReply, faUser } from '@fortawesome/free-solid-svg-icons'
import { history } from "../../../store";
import * as constant from '../../../constant/constant';
import { call } from '../../../service/service';
import { SUBSCRIPTIONUPDATE } from '../../../api/api';

function mapStateToProps(state) {
    return {
        loading: state.ACTIONS.loading,
        grades: state.GRADES,
        payments: state.PAYMENTS,
        getSubscription: state.SUBSCRIPTIONDETAILS
    };
}

function mapDispatchToProps(dispatch) {
    return {
        setLoader: (val) => {
            dispatch({ type: constant.loading, payload: val });
        }, update: (data) => {
            dispatch(call(data))
        }
    };
}

class SubscriptionDetails extends Component {
    state = {
        start: this.getCurrentDate(new Date()),
        end: this.getCurrentDate(new Date())
    }
    backToList(e) {
        history.push("/twotr/subscriptions");
    }
    updateStatus(id, activate) {


    }
    getCurrentDate(val = new Date()) {
        var date = new Date(val);
        return date.getFullYear() + "/" + date.getMonth() + 1 + "/" + date.getDate()
    }
    componentDidMount() {
        if (this.props.getSubscription && this.props.getSubscription.title)
            this.setState(this.props.getSubscription);
    }
    componentDidUpdate(nextProps) {
        if (nextProps.loading === 2 && nextProps.loading !== this.props.loading) {
            history.push("/twotr/subscriptions");
        }

        if (nextProps.getSubscription.title !== this.props.getSubscription.title) {
            this.setState(this.props.getSubscription);
        }
        return null;
    }
    onchange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }
    loadImage = () => {
    }
    save = (id) => {
        this.props.setLoader(2);
        SUBSCRIPTIONUPDATE.params = this.state;
        if (this.state._id) {
            SUBSCRIPTIONUPDATE.url = "https://api.twotr.com/api/admin/subscription/update/" + this.props.getSubscription._id;
        } else {
            SUBSCRIPTIONUPDATE.url = "https://api.twotr.com/api/admin/subscription/create";
        }
        this.props.update(SUBSCRIPTIONUPDATE)
    }

    isUpdate() {
        return this.props.location.pathname === "/twotr/subscriptionsUpdate";
    }

    loadGrade() {
        var element = [];
        for (let item in this.props.grades) {
            element.push(<option value={this.props.grades[item]} > {this.props.grades[item]}</option>)
        }
        return element;
    }

    loadPayment() {
        var element = [];
        for (let item in this.props.payments) {
            element.push(<option value={this.props.payments[item]} > {this.props.payments[item]}</option>)
        }
        return element;
    }
    getDateValue(val, type) {
        debugger;
        if (this.state.end || this.state.start) {
            if (type === 1)
                return this.state.start.split('T')[0];
            else
                return this.state.end.split('T')[0];
        }
        else
            return new Date();
    }

    onCheckboxChange() {
        this.setState({ isLifetime: !this.state.isLifetime });
    }
    onchangeMulti(e) {
        debugger;
        this.setState({ gradeLevel: e.target.value });
    }

    render() {
        return (
            <React.Fragment>
                <div className="row" style={{ marginTop: '15px' }}>
                    <div className="col-12">
                        <FontAwesomeIcon className="backBtn" icon={faReply} onClick={(e) => this.backToList(e)} />
                    </div>
                </div>
                <div className="row table form-container" style={{ marginTop: '15px' }}>
                    <div className="col-6">
                        <div className="headerText">Title</div>
                        <div>
                            <input type="text" placeholder="Title" name="title" value={this.state.title} onChange={(e) => this.onchange(e)} />
                        </div>
                    </div>

                    <div className="col-6">
                        <div className="headerText">Price</div>
                        <input type="text" placeholder="Price" name="price" value={this.state.price} onChange={(e) => this.onchange(e)} />
                    </div>
                    <div className="col-6">
                        <div className="headerText">Payment Type</div>
                        <select className="paymentDrop" name="paymentType" value={this.state.paymentType} onChange={(e) => this.onchange(e)}>
                            {this.loadPayment()}
                        </select>
                    </div>

                    <div className="col-6">
                        <div className="headerText">Valid Days</div>
                        <input type="text" placeholder="Valid Days" name="validDays" value={this.state.validDays} onChange={(e) => this.onchange(e)} />
                    </div>
                    <div className="col-6">
                        <div className="headerText">Start</div>
                        <input type="date" placeholder="Start" name="start" value={this.getDateValue(this.state.start, 1)} onChange={(e) => this.onchange(e)} />
                    </div>
                    <div className="col-6">
                        <div className="headerText">End</div>
                        <input type="date" placeholder="End" name="end" value={this.getDateValue(this.state.end, 2)} onChange={(e) => this.onchange(e)} />
                    </div>
                    <div className="col-6">
                        <div className="headerText">Grade Level </div>
                        <select multiple className="gradeBox" name="gradeLevel[]" value={this.state.gradeLevel} onChange={(e) => this.onchangeMulti(e)}>
                            {
                                this.loadGrade()
                            }


                        </select>
                    </div>
                    <div className="col-6">
                        <div className="headerText">Description</div>
                        <textarea className="gradeBox" placeholder="Description" name="description" value={this.state.description} onChange={(e) => this.onchange(e)}></textarea>
                    </div>
                    <div className="col-6">
                        <div className="headerText">LIfetime</div>
                        <input name="isLifetime" defaultChecked={this.state.isLifetime} onChange={(e) => this.onCheckboxChange(e)} type="checkbox" />
                    </div>
                    {/* <div className="col-6">
                        <div className="headerText">Grade Level</div>
                        
                    </div> */}
                    {this.isUpdate() &&
                        <div className="col-12 submitBlogs">
                            <button className="p-btn disableBtn" onClick={(e) => this.save(e)}>
                                {this.props.loading === 2 ?
                                    <div className="btn-loader"></div>
                                    :
                                    <div>Submit</div>
                                }

                            </button>
                        </div>
                    }
                </div>

            </React.Fragment>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(SubscriptionDetails);