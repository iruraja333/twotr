import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBookOpen, faTrash, faUserEdit } from '@fortawesome/free-solid-svg-icons'
import * as constant from '../../../constant/constant';
import { SUBSCRIPTIONDETAILS, DELETEBLOG } from '../../../api/api';
import { call } from '../../../service/service';
import { history } from "../../../store";
function mapStateToProps(state) {
    return {
        getSubscription: state.SUBSCRIPTIONDETAILS,
        loading: state.ACTIONS.loading
    };
}

function mapDispatchToProps(dispatch) {
    return {
        setEditLoad: (val) => {
            dispatch({ type: constant.editLoading, payload: val })
        },
        resetUpdateResult: (val) => {
            dispatch({ type: constant.UPDATEREFPOINT, payload: {} })
        },
        update: (data) => {
            dispatch(call(data))
        },
        getDetails: (data) => {
            dispatch(call(data))
        },
        setLoader: (val) => {
            dispatch({ type: constant.loading, payload: val });
        }
    };
}

class Subscriptions extends Component {
    state = {
        isUpdate: false
    }

    view(id) {
        this.setState({ isUpdate: false });
        SUBSCRIPTIONDETAILS.url = 'https://api.twotr.com/api/admin/subscription/' + id;
        this.props.getDetails(SUBSCRIPTIONDETAILS)
    }

    edit(id) {
        this.setState({ isUpdate: true })
        SUBSCRIPTIONDETAILS.url = 'https://api.twotr.com/api/admin/subscription/' + id;
        this.props.getDetails(SUBSCRIPTIONDETAILS)
    }

    delete(id) {
        DELETEBLOG.url = 'https://api.twotr.com/api/admin/blogpost/delete/' + id;
        this.props.getDetails(DELETEBLOG);
    }

    loadData() {
        return this.props.data.map((val, key) => {
            return <div key={key} className={`row ${key == this.state.editIndex ? "update-view" : ""}`}>
                <div className="col-2 elipse"> {val.title} </div>
                <div className="col-1 elipse"> {val.price}</div>
                <div className="col-1 elipse"> {val.paymentType}</div>

                <div className="col-3 elipse">{val.createdAt}</div>
                <div className="col-3 elipse">{val.end}</div>

                <div className="col-2 elipse">
                    <FontAwesomeIcon onClick={(e) => this.view(val._id)} className="actionIcon" icon={faBookOpen} />
                    <FontAwesomeIcon onClick={(e) => this.edit(val._id)} className="actionIcon" icon={faUserEdit} />
                    <FontAwesomeIcon onClick={(e) => this.delete(val._id)} className="actionIcon" icon={faTrash} />
                </div>

            </div>
        })
    }

    componentDidUpdate(prevProps) {
        if (prevProps.getSubscription._id !== this.props.getSubscription._id) {

            if (this.state.isUpdate)
                history.push("/twotr/subscriptionsUpdate");
            else
                history.push("/twotr/subscriptionsDetails");

        }
    }
    render() {
        return (
            <div className={`table ${this.props.loading === 1 && "loader"}`}>
                <div className="header">
                    <div className="row">
                        <div className="col-2"> Title</div>
                        <div className="col-1"> Price</div>
                        <div className="col-1"> Payment Type</div>
                        <div className="col-3">Start</div>
                        <div className="col-3">End</div>
                        <div className="col-2">Actions</div>
                    </div>
                </div>
                <div className="body">
                    {this.loadData()}
                </div>
            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Subscriptions);