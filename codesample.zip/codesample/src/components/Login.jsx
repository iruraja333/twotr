import React, { Component } from 'react';
import { connect } from 'react-redux';
import { call } from '../service/service'
import { login } from '../api/api';
import { history } from '../store';
import UsernameTextbox from './forms/username';
import PasswordTextbox from './forms/password';
import * as constant from '../constant/constant';

function mapStateToProps(state) {
    return {
        auth: state.LOGIN,
        loading: state.ACTIONS.loading
    };
}

function mapDispatchToProps(dispatch) {
    return {
        login: (data) => {
            dispatch(call(data))
        },
        showLoading: (val) => {
            dispatch({ type: constant.loading, payload: val })
        }

    };
}

class Login extends Component {
    state = {
        password: 'AmKh43211234',
        username: 'twotradm@gmail.com'
    }
    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }

    submit = (e) => {
        if (this.state.password && this.state.username) {
            login.params.username = this.state.username;
            login.params.passeord = this.state.password;
            this.props.showLoading(2);
            this.props.login(login);
        } else
            alert("Enter credential")
    }
    static getDerivedStateFromProps(nextProps, prevState) {
        //debugger;
        if (nextProps.auth._id) {
            debugger;
            localStorage.token = nextProps.auth.token;
            history.push("/twotr/tutors")
        }
        return;

    }
    render() {
        return (
            <div className="login">
                <div className="login-container">
                    <img src="https://blog.oxforddictionaries.com/wp-content/uploads/football-1.jpg" height="100px" style={{ padding: '10px' }} />
                    <UsernameTextbox
                        name="username"
                        placeholder="Username"
                        value={this.state.username}
                        onChange={(e) => this.onChange(e)}
                    ></UsernameTextbox>

                    <PasswordTextbox
                        name="password"
                        placeholder="Password"
                        value={this.state.password}
                        onChange={(e) => this.onChange(e)}
                    ></PasswordTextbox>

                    <div>
                        <button className="p-btn loginBtn" onClick={(e) => this.submit(e)}>
                            {this.props.loading === 2 ?
                                <div className="btn-loader"></div>
                                :
                                <div>Login</div>
                            }

                        </button>
                    </div>
                </div>
            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Login);