import React, { Component } from 'react';
import { connect } from 'react-redux';
import Header from './Header';
import SubMenu from './SubMenu';
import { Router, Route } from 'react-router';
import Tutor from './Tutor';
import Students from './Students';
import TutorDetails from './template/tutor/tutorDetails';
import StudentsDetails from './template/students/studentsDetails';
import AdminDetails from './template/admin/AdminDetails';
import AdminPermission from './template/admin/AdminPermission';
import Admin from './Admin';
import UserSubjects from './UserSubjects';
import AdminSubjects from './AdminSubjects';
import Blogs from './Blogs';
import BlogDetails from './template/blogs/BlogDetails';
import Subscriptions from './Subscriptions';
import SubscriptionDetails from '../components/template/subscriptions/SubscriptionDetails';

function mapStateToProps(state) {
    return {
        smallMenu: state.ACTIONS.smallMenu,
        editLoading: state.ACTIONS.editLoading
    };
}

function mapDispatchToProps(dispatch) {
    return {

    };
}

class Home extends Component {

    render() {
        return (
            <React.Fragment>
                <Header></Header>
                {this.props.editLoading &&
                    <div className="update-container"></div>
                }

                <div className={`main-container ${this.props.smallMenu ? 's_menu' : 'l_menu'}`}>
                    <div className="slide-menu">
                        <SubMenu></SubMenu>
                    </div>
                    <div className="body-content container-fluid">
                        <React.Fragment>
                            <Route path="/twotr/tutors" component={Tutor}></Route>
                            <Route path="/twotr/tutorDetails" component={TutorDetails}></Route>
                            <Route path="/twotr/students" component={Students}></Route>
                            <Route path="/twotr/studentsDetails" component={StudentsDetails}></Route>
                            <Route path="/twotr/admin" component={Admin}></Route>
                            <Route path="/twotr/adminDetails" component={AdminDetails}></Route>
                            <Route path="/twotr/permission" component={AdminPermission}></Route>
                            <Route path="/twotr/userSubjects" component={UserSubjects}></Route>
                            <Route path="/twotr/adminSubjects" component={AdminSubjects}></Route>
                            <Route path="/twotr/blogs" component={Blogs}></Route>
                            <Route path="/twotr/blogDetails" component={BlogDetails}></Route>
                            <Route path="/twotr/blogUpdate" component={BlogDetails}></Route>
                            <Route path="/twotr/subscriptions" component={Subscriptions}></Route>
                            <Route path="/twotr/subscriptionsUpdate" component={SubscriptionDetails}></Route>
                            <Route path="/twotr/subscriptionsDetails" component={SubscriptionDetails}></Route>
                            
                        </React.Fragment>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Home);