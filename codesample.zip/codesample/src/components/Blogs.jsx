import React, { Component } from 'react';
import { connect } from 'react-redux';
import List from './listview/List';
import { BLOGPOSTLIST } from '../api/api';
import { call } from '../service/service';
import * as constant from '../constant/constant';
import { history } from "../store";

function mapStateToProps(state) {
    return {
        blogsData: state.BLOGS,
        loading: state.ACTIONS.loading
    };
}

function mapDispatchToProps(dispatch) {
    return {
        fetchTutor: (data, loader) => {
            dispatch({ type: constant.loading, payload: loader || 1 });
            dispatch(call(data))
        }
    };
}

class Blogs extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            totalRecords: 0
        }
    }

    fetchData(page = 1, size = 10, params) {
        var { queryParams } = BLOGPOSTLIST;
        queryParams.page = page;
        queryParams.size = size;

        BLOGPOSTLIST.queryParams = queryParams;

        this.props.fetchTutor(BLOGPOSTLIST);
    }

    componentDidMount() {
        this.fetchData();
    }

    add() {
        history.push("/twotr/blogUpdate");
    }

    render() {
        return (
            <div className="row">
                <div class="col-12">
                    <div class="page-title">
                        <div class="pull-left">
                            <h1 class="title">Blog Post</h1>
                        </div>

                        <button className="p-btn disableBtn" onClick={(e) => this.add()}>
                            {this.props.loading === 2 ?
                                <div className="btn-loader"></div>
                                :
                                <div>ADD</div>
                            }

                        </button>

                    </div>
                </div>
                <div className="col-12">
                    {this.props.blogsData.parsedBlogposts && <List listType="blogs" loading={this.props.loading} sortData={BLOGPOSTLIST.params.sort} fetchData={this.fetchData.bind(this)} data={this.props.blogsData.parsedBlogposts} totalCount={this.props.blogsData.totalRecords}></List>}
                </div>
            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Blogs);
