import React, { Component } from 'react';
import TutorTemplate from '../template/tutor/Tutor';
import StudentsTemplate from '../template/students/Students';
import Admin from '../template/admin/Admin';
import UserSubjects from '../template/subjects/UserSubjects';
import AdminSubjects from '../template/subjects/AdminSubjects';
import Blogs from '../template/blogs/Blogs';
import Subscriptions from '../template/subscriptions/Subscriptions';

class List extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpen: false,
            recordSize: 10,
            activePage: 1,
            currentPageArray: [1, 2, 3]
        }
    }

    setRecordSize(val) {
        this.setState({ recordSize: val, isOpen: false })
    }

    pagination() {
        var pageLength = Number((this.props.totalCount / this.state.recordSize).toString().split('.')[0]);

        return <React.Fragment>
            <ul className="paging">

                {pageLength > 4 &&
                    <React.Fragment>
                        {this.state.activePage === 1 ?
                            <li className="dummyList" >Previous</li>
                            :
                            <li onClick={(e) => this.loadNextPageArray(this.state.activePage - 1)}>Previous</li>
                        }
                        {this.loadPage(pageLength)}

                        {this.state.activePage === pageLength ?
                            <li className="dummyList">Next</li>
                            :
                            <li onClick={(e) => this.loadNextPageArray(this.state.activePage + 1)}>Next</li>
                        }
                    </React.Fragment>
                }

                {pageLength <= 4 &&
                    <React.Fragment>
                        {pageLength >= 1 && <li onClick={(e) => this.setActivePage(1)} className={this.state.activePage === 1 ? "active" : ""}>1</li>}
                        {pageLength >= 2 && <li onClick={(e) => this.setActivePage(2)} className={this.state.activePage === 2 ? "active" : ""}>2</li>}
                        {pageLength >= 3 && <li onClick={(e) => this.setActivePage(3)} className={this.state.activePage === 3 ? "active" : ""}>3</li>}
                        {pageLength >= 4 && <li onClick={(e) => this.setActivePage(4)} className={this.state.activePage === 4 ? "active" : ""}>4</li>}
                    </React.Fragment>
                }

            </ul>
            <ul className="paging selectP">
                <li className="select" onClick={(e) => this.openDrop(e)}>
                    <div className="select_dot"> {this.state.recordSize} </div>
                    <div className="select_arrow" ></div>
                    <ul style={{ top: this.state.Y - 200, left: this.state.X }} className={this.state.isOpen ? "open" : "close"}>
                        <li onClick={(e) => this.setRecordSize(10)}>10</li>
                        <li onClick={(e) => this.setRecordSize(20)}>20</li>
                        <li onClick={(e) => this.setRecordSize(50)}>50</li>
                        <li onClick={(e) => this.setRecordSize(100)}>100</li>
                    </ul>
                </li>
            </ul>
        </React.Fragment>
    }

    openDrop(e) {
        this.setState({ X: e.nativeEvent.layerX, Y: e.nativeEvent.pageY, isOpen: !this.state.isOpen })
    }

    setActivePage(val) {
        if (val !== this.state.activePage)
            this.setState({ activePage: val })
    }

    loadPage(pageLength) {
        return <React.Fragment>
            <li className={this.state.currentPageArray[0] === this.state.activePage ? "active" : ""} onClick={(e) => this.setActivePage(this.state.currentPageArray[0])} >{this.state.currentPageArray[0]}</li>
            <li className={this.state.currentPageArray[1] === this.state.activePage ? "active" : ""} onClick={(e) => this.setActivePage(this.state.currentPageArray[1])} >{this.state.currentPageArray[1]}</li>
            <li className={this.state.currentPageArray[2] === this.state.activePage ? "active" : ""} onClick={(e) => this.setActivePage(this.state.currentPageArray[2])} >{this.state.currentPageArray[2]}</li>
            <li className="dummyList">...</li>
            <li className={pageLength === this.state.activePage ? "active" : ""} onClick={(e) => this.setActivePage(pageLength)}>{pageLength}</li>
        </React.Fragment>
    }

    loadNextPageArray(page) {
        var pageLength = Number((this.props.totalCount / this.state.recordSize).toString().split('.')[0]);
        var activePage = this.state.activePage % 3, nextPage = page;
        if (nextPage < 4) {
            this.setState({ activePage: nextPage });
        } else if (this.state.activePage === pageLength) {
            this.setState({ currentPageArray: [1, 2, 3], activePage: nextPage });
        } else {
            this.setState({ currentPageArray: [...Array(pageLength + 1).keys()].slice(nextPage - 2, nextPage + 1), activePage: nextPage });
        }
    }

    loadPageArray(page) {
        var pageLength = Number((this.props.totalCount / this.state.recordSize).toString().split('.')[0]);
        var activePage = this.state.activePage % 3, nextPage = page;
        if (nextPage < 4) {
            this.setState({ currentPageArray: [1, 2, 3], activePage: nextPage });
        } else if (this.state.activePage === pageLength) {
            this.setState({ currentPageArray: [1, 2, 3], activePage: nextPage });
        } else {
            this.setState({ currentPageArray: [...Array(pageLength + 1).keys()].slice(nextPage - 2, nextPage + 1), activePage: nextPage });
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.state.activePage !== prevState.activePage) {
            this.props.fetchData(this.state.activePage, this.state.recordSize);
        }

    }

    render() {
        return (
            <React.Fragment>
                {this.props.listType === "user" &&
                    <TutorTemplate {...this.props} page={this.state.activePage} size={this.state.recordSize}></TutorTemplate>
                }
                {this.props.listType === "students" &&
                    <StudentsTemplate {...this.props} page={this.state.activePage} size={this.state.recordSize}></StudentsTemplate>
                }
                {this.props.listType === "admin" &&
                    <Admin {...this.props} page={this.state.activePage} size={this.state.recordSize}></Admin>
                }
                {this.props.listType === "usersubject" &&
                    <UserSubjects {...this.props} page={this.state.activePage} size={this.state.recordSize}></UserSubjects>
                }
                {this.props.listType === "adminsubject" &&
                    <AdminSubjects {...this.props} page={this.state.activePage} size={this.state.recordSize}></AdminSubjects>
                }
                {this.props.listType === "blogs" &&
                    <Blogs {...this.props} page={this.state.activePage} size={this.state.recordSize}></Blogs>
                }
                {this.props.listType === "subscriptions" &&
                    <Subscriptions {...this.props} page={this.state.activePage} size={this.state.recordSize}></Subscriptions>
                }


                {this.pagination()}
            </React.Fragment>
        );
    }
}

export default List;

