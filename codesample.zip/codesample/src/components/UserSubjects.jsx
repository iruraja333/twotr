import React, { Component } from 'react';
import { connect } from 'react-redux';
import List from './listview/List';
import { USERSUBJECTS } from '../api/api';
import { call } from '../service/service';
import * as constant from '../constant/constant';

function mapStateToProps(state) {
    return {
        userSujectData: state.USERSUBJECTS,
        loading: state.ACTIONS.loading
    };
}

function mapDispatchToProps(dispatch) {
    return {
        fetchTutor: (data, loader) => {
            dispatch({ type: constant.loading, payload: loader || 1 });
            dispatch(call(data))
        }
    };
}

class UserSubjects extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            totalRecords: 0
        }
    }

    fetchData(page = 1, size = 10, params) {
        var { queryParams } = USERSUBJECTS;
        queryParams.page = page;
        queryParams.size = size; 

        USERSUBJECTS.queryParams = queryParams;

        this.props.fetchTutor(USERSUBJECTS);
    }

    componentDidMount() {
        this.fetchData();
    }


    render() {
        return (
            <div className="row">
                <div class="col-12">
                    <div class="page-title">
                        <div class="pull-left">
                            <h1 class="title">User Subjects</h1>
                        </div>
                    </div>
                </div>
                <div className="col-12">
                    {this.props.userSujectData.subjects && <List listType="usersubject" loading={this.props.loading} sortData={USERSUBJECTS.params.sort} fetchData={this.fetchData.bind(this)} data={this.props.userSujectData.subjects} totalCount={this.props.userSujectData.totalRecords}></List>}
                </div>
            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(UserSubjects);
