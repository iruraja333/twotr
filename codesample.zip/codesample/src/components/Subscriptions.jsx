import React, { Component } from 'react';
import { connect } from 'react-redux';
import List from './listview/List';
import { SUBSCRIPTIONSLIST, GRADES, PAYMENTS } from '../api/api';
import { call } from '../service/service';
import * as constant from '../constant/constant';
import { history } from "../store";

function mapStateToProps(state) {
    return {
        subscriptionsData: state.SUBSCRIPTIONS,
        loading: state.ACTIONS.loading
    };
}

function mapDispatchToProps(dispatch) {
    return {
        fetchTutor: (data, loader) => {
            dispatch({ type: constant.loading, payload: loader || 1 });
            dispatch(call(data))
        },
        fetchPaymentGrade: (data, loader) => {
            dispatch({ type: constant.loading, payload: loader || 2 });
            dispatch(call(data))
        },
        resetDetails: (val) => {
            dispatch({ type: constant.SUBSCRIPTIONDETAILS, payload: val })
        }
    };
}

class Subscriptions extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            totalRecords: 0
        }
    }

    fetchData(page = 1, size = 10, params) {
        var { queryParams } = SUBSCRIPTIONSLIST;
        queryParams.page = page;
        queryParams.size = size;

        SUBSCRIPTIONSLIST.queryParams = queryParams;

        this.props.fetchTutor(SUBSCRIPTIONSLIST);
    }
    getPaymentGrade() {
        this.props.fetchPaymentGrade(GRADES);
        this.props.fetchPaymentGrade(PAYMENTS);
    }
    componentDidMount() {
        this.fetchData();
        this.getPaymentGrade();
    }

    add() {
        this.props.resetDetails({});
        history.push("/twotr/subscriptionsUpdate");
    }

    render() {
        return (
            <div className="row">
                <div class="col-12">
                    <div class="page-title">
                        <div class="pull-left">
                            <h1 class="title">Blog Post</h1>
                        </div>

                        <button className="p-btn disableBtn" onClick={(e) => this.add()}>
                            {this.props.loading === 2 ?
                                <div className="btn-loader"></div>
                                :
                                <div>ADD</div>
                            }

                        </button>

                    </div>
                </div>
                <div className="col-12">
                    {this.props.subscriptionsData.subscriptions && <List listType="subscriptions" loading={this.props.loading} sortData={SUBSCRIPTIONSLIST.params.sort} fetchData={this.fetchData.bind(this)} data={this.props.subscriptionsData.subscriptions} totalCount={this.props.subscriptionsData.totalRecords}></List>}
                </div>
            </div>
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Subscriptions);
