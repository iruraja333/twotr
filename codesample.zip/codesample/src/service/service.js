import axios from 'axios'
import * as constant from '../constant/constant';
import { history } from "../store";

function call(req) {
    return function(dispatch){
    axios({
        method:req.method,
        url:req.url,
        data:req.params,
        params:req.queryParams,
        headers:req.headers
    }).then((res)=>{
        dispatch({type:req.type,payload:res.data});
        dispatch({type:constant.loading,payload:false});
    }).catch((error)=>{
        if(error.response && error.response.status===401)
            history.push("/login");
        dispatch({type:constant.loading,payload:false});
        dispatch({type:req.type,payload:error});
    })
} 
}

export {call}