import { combineReducers} from 'redux';
import {_TUTOR,_LOGIN, _UPDATEREFPOINT, _GETUSERDETAILS,_STATUSUPDATE, _UPDATEDETAILS} from './actions/login';
import {_STUDENTS} from './actions/students';
import {_ADMIN, _PERMISSIONS} from './actions/admin';
import {_USERSUBJECTS, _USERAPPROVE} from './actions/userSubject';
import _ACTIONS from './actions/actions';
import {_BLOGS} from './actions/blogs';
import {_SUBSCRIPTIONS, _PAYMENTS, _GRADES, _SUBSCRIPTIONDETAILS} from './actions/subscriptions';

export default combineReducers({
    LOGIN: _LOGIN,
    ACTIONS:_ACTIONS,
    TUTOR:_TUTOR,
    UPDATEREFPOINT:_UPDATEREFPOINT,
    GETUSERDETAILS:_GETUSERDETAILS,
    STUDENTS:_STUDENTS,
    STATUSUPDATE:_STATUSUPDATE,
    ADMIN:_ADMIN,
    PERMISSIONS:_PERMISSIONS,
    USERSUBJECTS:_USERSUBJECTS,
    USERAPPROVE:_USERAPPROVE,
    BLOGS:_BLOGS,
    UPDATEDETAILS:_UPDATEDETAILS,
    SUBSCRIPTIONS:_SUBSCRIPTIONS,
    GRADES:_GRADES,
    PAYMENTS:_PAYMENTS,
    SUBSCRIPTIONDETAILS:_SUBSCRIPTIONDETAILS
});