import * as constant from '../../constant/constant';

export function _ADMIN(state={},action){
    switch(action.type){
        case constant.ADMIN:
            return action.payload
        default:
            return state;
    }
}

export function _PERMISSIONS(state={},action){
    switch(action.type){
        case constant.PERMISSIONS:
            return action.payload
        default:
            return state;
    }
}


