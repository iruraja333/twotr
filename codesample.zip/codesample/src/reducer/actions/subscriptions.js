import * as constant from '../../constant/constant';

export function _SUBSCRIPTIONS(state={},action){
    switch(action.type){
        case constant.SUBSCRIPTIONS:
            return {...action.payload}
        default:
            return state;
    }
}

export function _GRADES(state=[],action){
    switch(action.type){
        case constant.GRADES:
            return {...action.payload}
        default:
            return state;
    }
}

export function _PAYMENTS(state=[],action){
    switch(action.type){
        case constant.PAYMENTS:
            return {...action.payload}
        default:
            return state;
    }
}

export function _SUBSCRIPTIONDETAILS(state={},action){
    switch(action.type){
        case constant.SUBSCRIPTIONDETAILS:
            return {...action.payload}
        default:
            return state;
    }
}

