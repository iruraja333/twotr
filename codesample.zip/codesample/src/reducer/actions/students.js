import * as constant from '../../constant/constant';

export function _STUDENTS(state={},action){
    switch(action.type){
        case constant.STUDENTS:
            return action.payload
        default:
            return state;
    }
}


