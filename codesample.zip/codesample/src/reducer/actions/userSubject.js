import * as constant from '../../constant/constant';

export function _USERSUBJECTS(state={},action){
    switch(action.type){
        case constant.USERSUBJECTS:
            return action.payload
        default:
            return state;
    }
}

export function _USERAPPROVE(state={},action){
    switch(action.type){
        case constant.USERAPPROVE:
            return action.payload
        default:
            return state;
    }
}


