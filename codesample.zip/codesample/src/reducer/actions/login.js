import * as constant from '../../constant/constant';

export function _LOGIN(state={},action){
    switch(action.type){
        case constant.LOGIN:
            return action.payload
        default:
            return state;
    }
}

export function _TUTOR(state={},action){
    switch(action.type){
        case constant.TUTOR:
            return action.payload
        default:
            return state;
    }
}

export function _UPDATEREFPOINT(state={},action){
    switch(action.type){
        case constant.UPDATEREFPOINT:
            return action.payload
        default:
            return state;
    }
}

export function _GETUSERDETAILS(state={},action){
    switch(action.type){
        case constant.GETUSERDETAILS:
            return action.payload
        default:
            return state;
    }
}

export function _STATUSUPDATE(state={},action){
    switch(action.type){
        case constant.STATUSUPDATE:
            return action.payload
        default:
            return state;
    }
}

export function _UPDATEDETAILS(state={},action){
    switch(action.type){
        case constant.UPDATEDETAILS:
            return action.payload
        default:
            return state;
    }
}

