import * as constant from '../../constant/constant';

export function _BLOGS(state={},action){
    switch(action.type){
        case constant.BLOGPOSTLIST:
            return action.payload
        default:
            return state;
    }
}


