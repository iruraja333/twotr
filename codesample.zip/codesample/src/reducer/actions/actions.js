import * as constant from '../../constant/constant';
export default function _ACTIONS(state={smallMenu:false},action){
    switch(action.type){
        case constant.loading:
            return {...state,loading:action.payload}
        case constant.editLoading:
            return {...state,editLoading:action.payload}
        case constant.smallMenu:
            return {...state,smallMenu:action.payload}
        case constant.activeMenu:
            return {...state,activeMenu:action.payload}
        
        default:
            return state;
    }
}