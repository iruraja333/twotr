// we can render this page using server-render for security purpose


import * as constants from '../constant/constant';

export const authHeaders={
    'Content-Type':'application/json',
    'Authorization':'Bearer '+localStorage.token
}

export const login={
    method:'POST',
    url:'https://api.twotr.com/api/admin/auth/login',
    params:{
        password:'AmKh43211234',
        username:'twotradm@gmail.com'
    },
    headers:{
        'Content-Type':'application/json'
    },
    type:constants.LOGIN
}

export const TUTOR={
    method:'POST',
    url:'https://api.twotr.com/api/admin/users/list/tutor',
    queryParams:{
        page:1,
        size:10
    },
    headers:authHeaders,
    params:{sort:
        [{ascending: false,direction: "none",ignoreCase: false,propertyName: "firstName"},
        {ascending: false,direction: "none",ignoreCase: false,propertyName: "email"},
        {ascending: false,direction: "desc",ignoreCase: false,propertyName: "createdAt"}]
    },
    type:constants.TUTOR
}

export const STUDENTS={
    method:'POST',
    url:'https://api.twotr.com/api/admin/users/list/student',
    queryParams:{
        page:1,
        size:10
    },
    headers:authHeaders,
    params:{sort:
        [{ascending: false,direction: "none",ignoreCase: false,propertyName: "firstName"},
        {ascending: false,direction: "none",ignoreCase: false,propertyName: "email"},
        {ascending: false,direction: "desc",ignoreCase: false,propertyName: "createdAt"}]
    },
    type:constants.STUDENTS
}


export const ADMIN={
    method:'POST',
    url:'https://api.twotr.com/api/admin/users/admin/list/admin',
    queryParams:{
        page:1,
        size:10
    },
    headers:authHeaders,
    params:{sort:
        [{ascending: false,direction: "none",ignoreCase: false,propertyName: "firstName"},
        {ascending: false,direction: "none",ignoreCase: false,propertyName: "email"},
        {ascending: false,direction: "desc",ignoreCase: false,propertyName: "createdAt"}]
    },
    type:constants.ADMIN
}

// export const ADDADMIN={
//     method:'POST',
//     url:'https://api.twotr.com/api/admin/subject/list?page=1&size=10',
//     params:{},
//     headers:authHeaders,
//     type:constants.SUBJECTLIST
// }


export const USERSUBJECTS={
    method:'GET',
    url:'https://api.twotr.com/api/admin/subject/user/list',
    queryParams:{
        page:1,
        size:10
    },
    params:{
        sort:[{ascending: false,direction: "none",ignoreCase: false,propertyName: "title"}]
    },
    headers:authHeaders,
    type:constants.USERSUBJECTS
}

export const USERAPPROVE={
    method:'POST',
    url:'https://api.twotr.com/api/admin/subject/approve',
    params:{
        id:"",
        isApproved:false
    },
    headers:authHeaders,
    type:constants.USERAPPROVE
}


export const ADMINUSERLIST={
    method:'GET',
    url:'https://api.twotr.com/api/admin/subject/list?page=1&size=10',
    queryParams:{
        page:1,
        size:10
    },
    params:{
        sort:[{ascending: false,direction: "none",ignoreCase: false,propertyName: "title"}]
    },
    headers:authHeaders,
    type:constants.USERSUBJECTS
}

export const TITLEUPDATE={
    method:'POST',
    url:'https://api.twotr.com/api/admin/subject/default/update',
    params:{
        id:"",
        title:""
    },
    headers:authHeaders,
    type:constants.USERAPPROVE
}

export const ADDTITLE={
    method:'POST',
    url:'https://api.twotr.com/api/admin/subject/default/create',
    params:{
        id:"",
        title:""
    },
    headers:authHeaders,
    type:constants.USERAPPROVE
}


export const BLOGPOSTLIST={
    method:'GET',
    url:'https://api.twotr.com/api/admin/blogpost/list',
    queryParams:{
        page:1,
        size:10
    },
    params:{
        sort:[{ascending: false,direction: "none",ignoreCase: false,propertyName: "title"}]
    },
    headers:authHeaders,
    type:constants.BLOGPOSTLIST
}

export const SUBSCRIPTIONSLIST={
    method:'GET',
    url:'https://api.twotr.com/api/admin/subscription/list',
    queryParams:{
        page:1,
        size:10
    },
    params:{
        sort:[{ascending: false,direction: "none",ignoreCase: false,propertyName: "title"}]
    },
    headers:authHeaders,
    type:constants.SUBSCRIPTIONS
}

export const GRADES={
    method:'GET',
    url:'https://api.twotr.com/api/userinfo/grades',
    params:{},
    headers:authHeaders,
    type:constants.GRADES
}

export const PAYMENTS={
    method:'GET',
    url:'https://api.twotr.com/api/userinfo/payments',
    params:{},
    headers:authHeaders,
    type:constants.PAYMENTS
}

export const SUBSCRIPTIONDETAILS={
    method:'GET',
    url:'https://api.twotr.com/api/admin/subscription/',
    params:{},
    headers:authHeaders,
    type:constants.SUBSCRIPTIONDETAILS
}

export const SUBSCRIPTIONLIST={
    method:'POST',
    url:'https://api.twotr.com/api/admin/subscription/list?page=1&size=10',
    params:{},
    headers:authHeaders,
    type:constants.SUBSCRIPTIONLIST
}

export const CHATHISTORY={
    method:'POST',
    url:'https://api.twotr.com/api/admin/chat/history/list?page=1&size=10',
    params:{},
    headers:authHeaders,
    type:constants.CHATHISTORY
}

export const ACCOUNTSUBSCRIPTION={
    method:'POST',
    url:'https://api.twotr.com/api/admin/accounts/subscription/group?page=1&size=10',
    params:{},
    headers:authHeaders,
    type:constants.ACCOUNTSUBSCRIPTION
}

export const ACCOUNTSCHEDULE={
    method:'POST',
    url:'https://api.twotr.com/api/admin/accounts/schedule/group?page=1&size=10',
    params:{},
    headers:authHeaders,
    type:constants.ACCOUNTSCHEDULE
}

export const GETALL={
    method:'POST',
    url:'https://api.twotr.com/api/admin/settings/getAll',
    params:{},
    headers:authHeaders,
    type:constants.GETALL
}

export const DASHBOARD={
    method:'POST',
    url:'https://api.twotr.com/api/admin/dashboard/all',
    params:{},
    headers:authHeaders,
    type:constants.DASHBOARD
}

export const PERMISSIONS={
    method:'GET',
    url:'https://api.twotr.com/api/admin/user/permission/get/',
    params:{},
    headers:authHeaders,
    type:constants.PERMISSIONS
}

export const UPDATEREFERPOINT={
    method:'POST',
    url:'https://api.twotr.com/api/admin/points/update/',
    params:{points:0},
    headers:authHeaders,
    type:constants.UPDATEREFPOINT
}

export const GETUSERDETAILS={
    method:'GET',
    url:'https://api.twotr.com/api/admin/users/get/',
    params:{},
    headers:authHeaders,
    type:constants.GETUSERDETAILS
    
}

export const STATUSUPDATE={
    method:'PUT',
    url:'https://api.twotr.com/api/admin/users/activate/',
    params:{activate:false},
    headers:authHeaders,
    type:constants.STATUSUPDATE
    
}

export const GETUSERBLOGDETAILS={
    method:'GET',
    url:'https://api.twotr.com/api/admin/blogpost/',
    params:{},
    headers:authHeaders,
    type:constants.UPDATEDETAILS
    
}

export const BLOGUPDATE={
    method:'POST',
    url:'https://api.twotr.com/api/admin/blogpost/update/',
    params:{},
    headers:authHeaders,
    type:constants.UPDATEDETAILS
}


export const DELETEBLOG={
    method:'DELETE',
    url:'https://api.twotr.com/api/admin/blogpost/',
    params:{},
    headers:authHeaders,
    type:constants.UPDATEDETAILS
    
}

export const SUBSCRIPTIONUPDATE={
    method:'POST',
    url:'https://api.twotr.com/api/admin/subscription/update/',
    params:{},
    headers:authHeaders,
    type:constants.UPDATEDETAILS
}